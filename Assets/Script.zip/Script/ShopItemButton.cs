using UnityEngine;
using TMPro;

public class ShopItemButton : MonoBehaviour
{
    [Header("���i���")]
    [SerializeField] private int price;

    [SerializeField] private int addInk;

    [SerializeField] private ColorType inkColor;

    [SerializeField] private ShopManager shopManager;

    [SerializeField] private MoneyManager moneyManager;

    [SerializeField] private TMP_Text priceText;


    private void Start()
{
    if (priceText != null)
    {
        priceText.text = price + "G";
    }
}
    public void ClickItem()
    {
        shopManager.OpenConfirm(this);
    }

    public void Purchase()
    {
        if (!moneyManager.UseMoney(price))
        {
            Debug.Log("�������s��");
            return;
        }

        // �C���N�ǉ�
        InkManager.Instance.AddInk(inkColor, addInk);

        Debug.Log("�w������");
    }
}

public enum InkColor
{
    Red,
    Blue,
    Yellow,
    AllColor
}