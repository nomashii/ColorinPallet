using UnityEngine;
using UnityEngine.EventSystems;


public class DragAndDropColor : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
{
    [SerializeField] private ColorMixManager colorMixManager;
    [SerializeField]private ColorType myColor;
    [SerializeField] private float reducedScale = 0.7f;


    private RectTransform rectTransform;
    private CanvasGroup canvasGroup;
   
    private GameObject cloneObject;
    private RectTransform cloneRectTransform;
    private CanvasGroup cloneCanvasGroup;


public ColorType GetColorType()
{
    return myColor;
}
    void Start()
    {
        rectTransform = GetComponent<RectTransform>();
        canvasGroup = GetComponent<CanvasGroup>();
        if (canvasGroup == null) canvasGroup = gameObject.AddComponent<CanvasGroup>();
    }


    public void OnBeginDrag(PointerEventData eventData)
    {
        cloneObject = Instantiate(gameObject, transform.parent);
        Destroy(cloneObject.GetComponent<DragAndDropColor>());


        cloneRectTransform = cloneObject.GetComponent<RectTransform>();
        cloneCanvasGroup = cloneObject.GetComponent<CanvasGroup>();
        cloneRectTransform.localScale = Vector3.one;


        if (cloneCanvasGroup != null)
        {
            cloneCanvasGroup.alpha = 0.8f;
            cloneCanvasGroup.blocksRaycasts = false; // 下のキャラを指がすり抜けて感知させる
        }


        rectTransform.localScale = new Vector3(reducedScale, reducedScale, 1f);
        canvasGroup.alpha = 0.5f;
    }


    public void OnDrag(PointerEventData eventData)
    {
        if (cloneRectTransform != null)
        {
            Canvas canvas = GetComponentInParent<Canvas>();
            if (canvas != null)
            {
                cloneRectTransform.anchoredPosition += eventData.delta / canvas.scaleFactor;
            }
        }
    }


    public void OnEndDrag(PointerEventData eventData)
    {
        Debug.Log("私の色は " + myColor);
        bool hitPlayer = false;


        // 自分のオブジェクト名を見て、送るカラー文字列を決める
        ColorType myColorType = myColor;
        Camera mainCamera = Camera.main;
        if (mainCamera != null)
        {
            Vector3 mousePos = Input.mousePosition;
            Vector2 worldPoint = mainCamera.ScreenToWorldPoint(mousePos);
            RaycastHit2D[] hits = Physics2D.RaycastAll(worldPoint, Vector2.zero);
            Debug.Log("Hit数：" + hits.Length);

foreach (var h in hits)
{
    Debug.Log("当たった：" + h.collider.name);
}


            foreach (var hit in hits)
            {
                if (hit.collider != null && hit.collider.name.Contains("MixArea"))
                {
                    ColorMixManager colorMixManager = FindFirstObjectByType<ColorMixManager>();

if (colorMixManager != null)
{
    colorMixManager.PutColor(myColorType);
}
break;
                    // ★新しく作った「PlayerFormController」をオバケちゃんから見つける
                    /*layerFormController playerForm = hit.collider.GetComponent<PlayerFormController>();
                    if (playerForm != null)
                    {
                        if (colorMixManager != null)
{
    Debug.Log("ColorMixManagerへ送信：" + myColorType);
    colorMixManager.PutColor(myColorType);
}
else
{
    Debug.LogError("ColorMixManagerが設定されていません！");
}
                    }
                    break;*/
                }
            }
        }


        if (cloneObject != null) Destroy(cloneObject);


        if (hitPlayer)
        {
            // プレビュー成功：何度でも上書きできるようblocksRaycastsはONのまま、パレットを少し薄くする
            canvasGroup.alpha = 1f;
        }
        else
        {
            rectTransform.localScale = Vector3.one;
            canvasGroup.alpha = 1f;
        }
    }
}
