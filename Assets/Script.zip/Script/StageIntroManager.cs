using System.Collections;
using UnityEngine;

public class StageIntroManager : MonoBehaviour
{
    [SerializeField] private CanvasGroup backgroundGroup;
    [SerializeField] private CanvasGroup stageImageGroup;

    [SerializeField] private PlayerController playerController;

    private void Start()
    {
        playerController.SetCanMove(false);

        StartCoroutine(StageIntro());
    }

    private IEnumerator StageIntro()
    {
        backgroundGroup.alpha = 0;
        stageImageGroup.alpha = 0;

        // 背景フェードイン
        while (backgroundGroup.alpha < 1)
        {
            backgroundGroup.alpha += Time.deltaTime * 2f;
            yield return null;
        }

        backgroundGroup.alpha = 1;

        // 少し待つ
        yield return new WaitForSeconds(0.2f);

        // タイトルフェードイン
        while (stageImageGroup.alpha < 1)
        {
            stageImageGroup.alpha += Time.deltaTime * 2f;
            yield return null;
        }

        stageImageGroup.alpha = 1;

        // 表示時間
        yield return new WaitForSeconds(1.2f);

        // タイトルフェードアウト
        while (stageImageGroup.alpha > 0)
        {
            stageImageGroup.alpha -= Time.deltaTime * 2f;
            yield return null;
        }

        stageImageGroup.alpha = 0;

        // 背景フェードアウト
        while (backgroundGroup.alpha > 0)
        {
            backgroundGroup.alpha -= Time.deltaTime * 2f;
            yield return null;
        }

        backgroundGroup.alpha = 0;

        playerController.SetCanMove(true);

        backgroundGroup.alpha = 0;
stageImageGroup.alpha = 0;

playerController.SetCanMove(true);
    }
}