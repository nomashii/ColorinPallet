using TMPro;
using UnityEngine;

public class MoneyUIManager : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI moneyText;
    [SerializeField] private MoneyManager moneyManager;

    private void Start()
    {
        moneyManager.OnMoneyChanged += UpdateMoneyUI;

        UpdateMoneyUI();
    }

    private void OnDestroy()
    {
        if (moneyManager != null)
            moneyManager.OnMoneyChanged -= UpdateMoneyUI;
    }

    private void UpdateMoneyUI()
    {
        moneyText.text = moneyManager.GetMoney() + "G";
    }
}