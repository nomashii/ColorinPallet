using UnityEngine;
using UnityEngine.EventSystems;

public class MixAreaDropHandler : MonoBehaviour, IDropHandler
{
    [SerializeField] private ColorMixManager colorMixManager;

    public void OnDrop(PointerEventData eventData)
    {
        DragAndDropColor drag =
            eventData.pointerDrag.GetComponent<DragAndDropColor>();

        if (drag == null)
            return;

        colorMixManager.PutColor(drag.GetColorType());

        Debug.Log("Drop成功：" + drag.GetColorType());
    }
}