using UnityEngine;

public class InkManager : MonoBehaviour
{
    public static InkManager Instance { get; private set; }

    public System.Action OnInkChanged;

    [Header("現在のインク残量")]
    [SerializeField] private float redInk = 10f;
    [SerializeField] private float blueInk = 10f;
    [SerializeField] private float yellowInk = 10f;
    [SerializeField] private float maxInk = 10f;

    public float MaxInk => maxInk;

    private void Awake()
    {
        Instance = this;
    }

    void Start()
    {
        Debug.Log("赤インク：" + redInk);
        Debug.Log("青インク：" + blueInk);
        Debug.Log("黄インク：" + yellowInk);
    }

    public float GetRedInk()
    {
        return redInk;
    }

    public float GetBlueInk()
    {
        return blueInk;
    }

    public float GetYellowInk()
    {
        return yellowInk;
    }

    public void AddInk(ColorType color, float amount)
    {
        switch (color)
        {
            case ColorType.Red:
                redInk += amount;
                break;

            case ColorType.Blue:
                blueInk += amount;
                break;

            case ColorType.Yellow:
                yellowInk += amount;
                break;

            case ColorType.AllColor:
                redInk += amount;
                blueInk += amount;
                yellowInk += amount;
                break;
        }

        redInk = Mathf.Clamp(redInk, 0, maxInk);
        blueInk = Mathf.Clamp(blueInk, 0, maxInk);
        yellowInk = Mathf.Clamp(yellowInk, 0, maxInk);

        Debug.Log("インク補充 赤:" + redInk + " 青:" + blueInk + " 黄:" + yellowInk);

        OnInkChanged?.Invoke();
    }

    public bool UseInk(ColorType color, float amount)
    {
        if (!CanUseColor(color, amount))
        {
            return false;
        }

        switch (color)
        {
            case ColorType.Red:
                redInk -= amount;
                break;
            case ColorType.Blue:
                blueInk -= amount;
                break;
            case ColorType.Yellow:
                yellowInk -= amount;
                break;
            case ColorType.Purple:
                redInk -= amount * 0.5f;
                blueInk -= amount * 0.5f;
                break;
            case ColorType.Green:
                blueInk -= amount * 0.5f;
                yellowInk -= amount * 0.5f;
                break;
            case ColorType.Orange:
                redInk -= amount * 0.5f;
                yellowInk -= amount * 0.5f;
                break;
        }

        Debug.Log("赤:" + redInk + " 青:" + blueInk + " 黄:" + yellowInk);

        OnInkChanged?.Invoke();

        return true;
    }

    public bool CanUseColor(ColorType color, float amount)
    {
        switch (color)
        {
            case ColorType.Red:
                return redInk >= amount;
            case ColorType.Blue:
                return blueInk >= amount;
            case ColorType.Yellow:
                return yellowInk >= amount;
            case ColorType.Purple:
                return redInk >= amount * 0.5f && blueInk >= amount * 0.5f;
            case ColorType.Green:
                return blueInk >= amount * 0.5f && yellowInk >= amount * 0.5f;
            case ColorType.Orange:
                return redInk >= amount * 0.5f && yellowInk >= amount * 0.5f;
            case ColorType.White:
                return true;
            default:
                return false;
        }
    }
}