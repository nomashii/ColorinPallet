using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class InkUIManager : MonoBehaviour
{
    [SerializeField] private InkManager inkManager;

    [SerializeField] private Slider redSlider;
    [SerializeField] private Slider blueSlider;
    [SerializeField] private Slider yellowSlider;

    [SerializeField] private Image redGauge;
    [SerializeField] private Image blueGauge;
    [SerializeField] private Image yellowGauge;

    [SerializeField] private TMP_Text redInkText;
    [SerializeField] private TMP_Text blueInkText;
    [SerializeField] private TMP_Text yellowInkText;

    [SerializeField] private TMP_Text SmallredInkText;
    [SerializeField] private TMP_Text SmallblueInkText;
    [SerializeField] private TMP_Text SmallyellowInkText;

    void Update()
    {
        float red = inkManager.GetRedInk();
        float blue = inkManager.GetBlueInk();
        float yellow = inkManager.GetYellowInk();
        float max = inkManager.MaxInk;

        redSlider.value = red;
        blueSlider.value = blue;
        yellowSlider.value = yellow;

        redGauge.fillAmount = red / max;
        blueGauge.fillAmount = blue / max;
        yellowGauge.fillAmount = yellow / max;

        redInkText.text = Mathf.CeilToInt(red) + "/" + Mathf.CeilToInt(max);
        blueInkText.text = Mathf.CeilToInt(blue) + "/" + Mathf.CeilToInt(max);
        yellowInkText.text = Mathf.CeilToInt(yellow) + "/" + Mathf.CeilToInt(max);

        SmallredInkText.text = Mathf.CeilToInt(red).ToString();
        SmallblueInkText.text = Mathf.CeilToInt(blue).ToString();
        SmallyellowInkText.text = Mathf.CeilToInt(yellow).ToString();
    }
}