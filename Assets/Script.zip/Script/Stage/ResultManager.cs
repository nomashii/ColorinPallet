using UnityEngine;

public class ResultManager : MonoBehaviour
{
    [SerializeField] private GameObject clearPanel;
    [SerializeField] private GameObject resultPanel;
    [SerializeField] private ResultUI resultUI;
    [SerializeField] private MoneyManager moneyManager;
    [SerializeField] private QuestManager questManager;
    [SerializeField] private StageGoalManager goalManager;
    [SerializeField] private ResultCalculator resultCalculator;
    [SerializeField]private CanvasGroup clearCanvasGroup;

    private bool canOpenResult = false;
    private bool rewardAdded = false;

    void Update()
    {
        if (!canOpenResult)
            return;

        if (Input.GetMouseButtonDown(0))
        {
            Debug.Log("クリック検知");
            OpenResult();
        }
    }

    public void ShowClearPanel()
    {
        Debug.Log("ShowClearPanel呼ばれた！");

        StartCoroutine(FadeInClearPanel());
    }
    private void EnableOpenResult()
{
    canOpenResult = true;
}

    private void OpenResult()
{
    Debug.Log("OpenResult呼ばれた！");
    clearCanvasGroup.alpha = 0f;
    clearPanel.SetActive(false);

    resultPanel.SetActive(true);

    resultUI.RefreshUI();

    canOpenResult = false;

    Debug.Log("リザルト画面を表示");

int totalReward =
    resultCalculator.GetClearBonus()
    + resultCalculator.GetResidentBonus()
    + resultCalculator.GetColorBonus();

moneyManager.AddMoney(totalReward);

Debug.Log("リザルト報酬：" + totalReward + "G");
}
    public int GetMoney()
{
    return moneyManager.GetMoney();
}

public int GetCompletedQuest()
{
    return questManager.GetCompletedQuest();
}

public int GetTotalQuest()
{
    return questManager.GetTotalQuest();
}

public int GetCompletedPaint()
{
    return goalManager.GetCompletedGoals();
}

public int GetTotalPaint()
{
    return goalManager.GetTotalGoals();
}

public void AddRewardToMoney()
{
    if (rewardAdded)
        return;

    moneyManager.AddMoney(resultCalculator.GetTotalReward());

    rewardAdded = true;
}
private System.Collections.IEnumerator FadeInClearPanel()
{
    clearPanel.SetActive(true);

    clearCanvasGroup.alpha = 0f;

    while (clearCanvasGroup.alpha < 1f)
    {
        clearCanvasGroup.alpha += Time.deltaTime * 2f;
        yield return null;
    }

    clearCanvasGroup.alpha = 1f;

    EnableOpenResult();
}
}