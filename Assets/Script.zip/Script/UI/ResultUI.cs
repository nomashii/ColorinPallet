using TMPro;
using UnityEngine;

public class ResultUI : MonoBehaviour
{
    

    [Header("表示UI")]
    [SerializeField] private GameObject[] stars;
    [SerializeField] private GameObject[] titles;
    [SerializeField] private GameObject[] comments;
    [SerializeField] private GameObject[] letters;
    [SerializeField] private ResultManager resultManager;
    [SerializeField]private ResultCalculator resultCalculator;
    [SerializeField] private TMP_Text rewardText;

public void RefreshUI()
{
    int star =
    resultCalculator.GetStarCount();

    Debug.Log("星の数 = " + star);
    Debug.Log("Stars配列 = " + stars.Length);
Debug.Log("Titles配列 = " + titles.Length);
Debug.Log("Comments配列 = " + comments.Length);
Debug.Log("Letters配列 = " + letters.Length);



foreach (GameObject obj in stars)
{
    obj.SetActive(false);
}
foreach (GameObject obj in titles)
{
    obj.SetActive(false);
}

foreach (GameObject obj in comments)
{
    obj.SetActive(false);
}

foreach (GameObject obj in letters)
{
    obj.SetActive(false);
}
for (int i = 0; i < star; i++)
{
    letters[i].SetActive(true);
}
for (int i = 0; i < star; i++)
{
    stars[i].SetActive(true);
}
comments[star].SetActive(true);
if (star > 0)
{
    titles[star - 1].SetActive(true);
}

    Debug.Log(resultManager);

    rewardText.text =
        resultCalculator.GetTotalReward() + " G";
}
}